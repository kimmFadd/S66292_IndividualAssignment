document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('shoppingForm').addEventListener('submit', function (event) {
        event.preventDefault();
        const amount = document.getElementById('shoppingAmount').value;
        saveExpense('Shopping', amount);
        alert('Shopping expense added!');
    });

    document.getElementById('foodForm').addEventListener('submit', function (event) {
        event.preventDefault();
        const amount = document.getElementById('foodAmount').value;
        saveExpense('Food', amount);
        alert('Food expense added!');
    });

    document.getElementById('transportForm').addEventListener('submit', function (event) {
        event.preventDefault();
        const amount = document.getElementById('transportAmount').value;
        saveExpense('Transport', amount);
        alert('Transport expense added!');
    });

    document.getElementById('hotelForm').addEventListener('submit', function (event) {
        event.preventDefault();
        const amount = document.getElementById('hotelAmount').value;
        saveExpense('Hotel', amount);
        alert('Hotel expense added!');
    });

    document.getElementById('flightForm').addEventListener('submit', function (event) {
        event.preventDefault();
        const amount = document.getElementById('flightAmount').value;
        saveExpense('Flight', amount);
        alert('Flight expense added!');
    });

    document.getElementById('activitiesForm').addEventListener('submit', function (event) {
        event.preventDefault();
        const amount = document.getElementById('activitiesAmount').value;
        saveExpense('Activities', amount);
        alert('Activities expense added!');
    });

    // Function to save expense (you can replace this with actual backend/API calls)
    function saveExpense(category, amount) {
        // Placeholder function for saving expense data
        console.log(`Saving ${category} expense: $${amount}`);
        // Save expense data to sessionStorage
        const expense = {
            category: category,
            amount: amount
        };
        let expenses = JSON.parse(sessionStorage.getItem('expenses')) || [];
        expenses.push(expense);
        sessionStorage.setItem('expenses', JSON.stringify(expenses));
        // Redirect to totalExpense.html after saving
        window.location.href = 'totalExpense.html';
    }
});
