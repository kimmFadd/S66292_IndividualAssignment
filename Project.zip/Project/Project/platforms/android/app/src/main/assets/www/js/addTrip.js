document.addEventListener('DOMContentLoaded', function () {
    // Handle form submission
    document.getElementById('tripForm').addEventListener('submit', function (event) {
        event.preventDefault(); // Prevent the default form submission

        // Get form values
        const name = document.getElementById('name').value;
        const currency = document.getElementById('currency').value;
        const budget = document.getElementById('budget').value;
        const start = document.getElementById('start').value;
        const end = document.getElementById('end').value;

        // Store trip information in sessionStorage
        sessionStorage.setItem('tripName', name);
        sessionStorage.setItem('tripCurrency', currency);
        sessionStorage.setItem('tripBudget', budget);
        sessionStorage.setItem('tripStart', start);
        sessionStorage.setItem('tripEnd', end);

        // Redirect to totalExpense.html
        window.location.href = 'totalExpense.html';
    });
});
