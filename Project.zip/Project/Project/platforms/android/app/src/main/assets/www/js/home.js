document.addEventListener("DOMContentLoaded", function () {
    // Handle button click event
    document.getElementById("addButton").addEventListener("click", function () {
        // Redirect to addTrip.html
        window.location.href = "addTrip.html";
    });
});
