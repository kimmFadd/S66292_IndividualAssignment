if (!sessionStorage.loggedin || sessionStorage.loggedin==null){
    location.href="home.html";
}
