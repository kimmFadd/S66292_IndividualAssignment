document.addEventListener('DOMContentLoaded', () => {
    const addTripBtn = document.getElementById('add-trip-btn');
    const tripModal = document.getElementById('trip-modal');
    const closeBtn = document.getElementsByClassName('close-btn')[0];
    const tripForm = document.getElementById('add-trip-form');
    const tripNameInput = document.getElementById('trip-name');
    const tripBudgetInput = document.getElementById('trip-budget');
    const tripsContainer = document.getElementById('trips-list');
    
    let trips = [];

    addTripBtn.addEventListener('click', () => {
        tripModal.style.display = 'block';
    });

    closeBtn.addEventListener('click', () => {
        tripModal.style.display = 'none';
    });

    window.addEventListener('click', (event) => {
        if (event.target == tripModal) {
            tripModal.style.display = 'none';
        }
    });

    tripForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const tripName = tripNameInput.value;
        const tripBudget = parseFloat(tripBudgetInput.value);

        const trip = {
            id: Date.now(),
            name: tripName,
            budget: tripBudget,
            expenses: [],
            totalExpenses: 0
        };

        trips.push(trip);
        renderTrips();
        
        tripNameInput.value = '';
        tripBudgetInput.value = '';
        tripModal.style.display = 'none';
    });

    function renderTrips() {
        tripsContainer.innerHTML = '';

        trips.forEach(trip => {
            const tripDiv = document.createElement('div');
            tripDiv.classList.add('trip');

            tripDiv.innerHTML = `
                <h3>${trip.name} - Budget: $${trip.budget}</h3>
                <p>Total Expenses: $${trip.totalExpenses}</p>
                <button onclick="removeTrip(${trip.id})">Remove Trip</button>
                <div>
                    <h4>Add Expense</h4>
                    <input type="text" placeholder="Expense Name" class="expense-name-${trip.id}">
                    <input type="number" placeholder="Expense Amount" class="expense-amount-${trip.id}">
                    <button onclick="addExpense(${trip.id})">Add Expense</button>
                </div>
                <div>
                    <h4>Expenses</h4>
                    <ul id="expenses-list-${trip.id}">
                    </ul>
                </div>
            `;

            tripsContainer.appendChild(tripDiv);
            renderExpenses(trip.id);
        });
    }

    window.removeTrip = (id) => {
        trips = trips.filter(trip => trip.id !== id);
        renderTrips();
    };

    window.addExpense = (tripId) => {
        const trip = trips.find(trip => trip.id === tripId);
        const expenseName = document.querySelector(`.expense-name-${tripId}`).value;
        const expenseAmount = parseFloat(document.querySelector(`.expense-amount-${tripId}`).value);

        const expense = {
            id: Date.now(),
            name: expenseName,
            amount: expenseAmount
        };

        trip.expenses.push(expense);
        trip.totalExpenses += expenseAmount;

        renderTrips();
    };

    function renderExpenses(tripId) {
        const trip = trips.find(trip => trip.id === tripId);
        const expensesList = document.getElementById(`expenses-list-${tripId}`);
        expensesList.innerHTML = '';

        trip.expenses.forEach(expense => {
            const expenseItem = document.createElement('li');
            expenseItem.textContent = `${expense.name}: $${expense.amount}`;
            expensesList.appendChild(expenseItem);
        });
    }
});
