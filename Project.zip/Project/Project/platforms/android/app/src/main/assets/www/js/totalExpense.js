document.addEventListener('DOMContentLoaded', function () {
    // Retrieve trip information from sessionStorage
    const tripName = sessionStorage.getItem('tripName');
    const tripCurrency = sessionStorage.getItem('tripCurrency');
    const tripBudget = sessionStorage.getItem('tripBudget');
    const tripStart = sessionStorage.getItem('tripStart');
    const tripEnd = sessionStorage.getItem('tripEnd');

    // Display trip information
    document.getElementById('tripName').textContent = tripName;
    document.getElementById('tripCurrency').textContent = tripCurrency;
    document.getElementById('tripBudget').textContent = tripBudget;
    document.getElementById('tripDates').textContent = `${tripStart} to ${tripEnd}`;

    // Retrieve expenses from sessionStorage
    const expenses = JSON.parse(sessionStorage.getItem('expenses')) || [];

    // Function to display expenses
    function displayExpenses() {
        const expensesList = document.getElementById('expensesList');
        expensesList.innerHTML = ''; // Clear existing items

        expenses.forEach((expense, index) => {
            const listItem = document.createElement('li');
            listItem.className = 'expense-item';
            listItem.innerHTML = `
                <div><strong>${expense.category}</strong></div>
                <div>Amount: ${expense.amount}</div>
            `;
            expensesList.appendChild(listItem);
        });
    }

    // Call the function to display expenses
    displayExpenses();
});
